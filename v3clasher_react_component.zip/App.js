import React, { useState, useRef, useEffect } from 'react';
import { Loader, Send, Image as ImageIcon, Plus, AlertCircle, Download, X, MoreVertical, WandSparkles, Palette } from 'lucide-react';
// --- Style Configuration ---
// [The rest of the code has been truncated for brevity, it will be in the actual file]
